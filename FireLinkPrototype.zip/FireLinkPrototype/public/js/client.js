// FireLink SOS Client JavaScript
const socket = io();

document.addEventListener('DOMContentLoaded', function() {
    const sosButton = document.getElementById('sosButton');
    const confirmModal = document.getElementById('confirmModal');
    const successModal = document.getElementById('successModal');
    const locationModal = document.getElementById('locationModal');
    const cancelSOS = document.getElementById('cancelSOS');
    const confirmSOS = document.getElementById('confirmSOS');
    const closeSuccess = document.getElementById('closeSuccess');
    const enableSound = document.getElementById('enableSound');
    const radiusSelect = document.getElementById('radiusSelect');
    
    let currentLocation = null;
    let pendingAlert = null;

    // Enable sound autoplay when checkbox is clicked
    enableSound.addEventListener('change', function() {
        if (this.checked) {
            // Try to play a silent audio to enable audio context
            const audio = new Audio();
            audio.volume = 0;
            audio.play().catch(e => {
                console.log('Audio context not enabled yet');
            });
        }
    });

    // SOS Button click handler
    sosButton.addEventListener('click', function() {
        // Get current location
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    currentLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    showConfirmModal();
                },
                function(error) {
                    console.log('Geolocation error:', error);
                    showLocationModal();
                }
            );
        } else {
            showLocationModal();
        }
    });

    // Manual location handling
    document.getElementById('useCurrentLocation').addEventListener('click', function(e) {
        e.preventDefault();
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    currentLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    hideLocationModal();
                    showConfirmModal();
                },
                function(error) {
                    alert('Unable to get location. Please enter manually.');
                }
            );
        }
    });

    document.getElementById('useManualLocation').addEventListener('click', function() {
        const lat = parseFloat(document.getElementById('manualLat').value);
        const lng = parseFloat(document.getElementById('manualLng').value);
        
        if (isNaN(lat) || isNaN(lng)) {
            alert('Please enter valid coordinates');
            return;
        }
        
        currentLocation = { lat, lng };
        hideLocationModal();
        showConfirmModal();
    });

    document.getElementById('cancelLocation').addEventListener('click', hideLocationModal);

    // Confirm SOS
    confirmSOS.addEventListener('click', function() {
        if (!currentLocation) {
            alert('Location required to send alert');
            return;
        }

        const radius = parseInt(radiusSelect.value);
        const alertData = {
            reporter_name: 'Community Member', // In real app, this would be user profile
            reporter_phone: '+1-xxx-xxx-xxxx', // In real app, this would be user profile
            lat: currentLocation.lat,
            lng: currentLocation.lng,
            message: 'Emergency assistance needed - house fire suspected',
            radius: radius
        };

        // Send alert to server
        fetch('/api/alerts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(alertData)
        })
        .then(response => response.json())
        .then(data => {
            hideConfirmModal();
            showSuccessModal(data);
        })
        .catch(error => {
            console.error('Error sending alert:', error);
            alert('Failed to send alert. Please try again.');
        });
    });

    // Cancel SOS
    cancelSOS.addEventListener('click', hideConfirmModal);
    closeSuccess.addEventListener('click', hideSuccessModal);

    // Modal functions
    function showConfirmModal() {
        confirmModal.style.display = 'block';
    }

    function hideConfirmModal() {
        confirmModal.style.display = 'none';
    }

    function showLocationModal() {
        locationModal.style.display = 'block';
    }

    function hideLocationModal() {
        locationModal.style.display = 'none';
    }

    function showSuccessModal(data) {
        const confirmationMessage = document.getElementById('confirmationMessage');
        const locationInfo = document.getElementById('locationInfo');
        const responseInfo = document.getElementById('responseInfo');

        confirmationMessage.textContent = 'Emergency alert sent successfully - neighbors and responders notified.';
        locationInfo.innerHTML = `<p><strong>Your location:</strong> ${currentLocation.lat.toFixed(6)}, ${currentLocation.lng.toFixed(6)}</p>`;
        responseInfo.innerHTML = `
            <p><strong>Devices notified:</strong> ${data.totalPinged || 0} community members within ${data.alert.radius}m</p>
            <p><strong>ETA:</strong> Emergency responders estimated 5-8 minutes</p>
            <p class="demo-hint">This is a demo - in production, real emergency services would be contacted.</p>
        `;

        successModal.style.display = 'block';
    }

    function hideSuccessModal() {
        successModal.style.display = 'none';
    }

    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === confirmModal) {
            hideConfirmModal();
        }
        if (event.target === successModal) {
            hideSuccessModal();
        }
        if (event.target === locationModal) {
            hideLocationModal();
        }
    });

    // Socket.IO connection for real-time updates
    socket.on('connect', function() {
        console.log('Connected to FireLink server');
        socket.emit('join_community');
    });

    socket.on('disconnect', function() {
        console.log('Disconnected from FireLink server');
    });

    // Listen for WebRTC call initiation
    socket.on('webrtc_offer', function(data) {
        handleIncomingCall(data);
    });

    // WebRTC functions for voice calling
    let localStream = null;
    let remoteStream = null;
    let peerConnection = null;

    async function handleIncomingCall(offer) {
        if (confirm('Incoming call from emergency responder. Accept?')) {
            await initializeWebRTC();
            await peerConnection.setRemoteDescription(offer);
            const answer = await peerConnection.createAnswer();
            await peerConnection.setLocalDescription(answer);
            socket.emit('webrtc_answer', answer);
        }
    }

    async function initializeWebRTC() {
        try {
            localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            peerConnection = new RTCPeerConnection({
                iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
            });

            localStream.getTracks().forEach(track => {
                peerConnection.addTrack(track, localStream);
            });

            peerConnection.ontrack = function(event) {
                remoteStream = event.streams[0];
                // In a real app, you'd play this audio
                console.log('Received remote stream');
            };

            peerConnection.onicecandidate = function(event) {
                if (event.candidate) {
                    socket.emit('webrtc_ice', event.candidate);
                }
            };

        } catch (error) {
            console.error('Error initializing WebRTC:', error);
        }
    }

    socket.on('webrtc_ice', function(candidate) {
        if (peerConnection) {
            peerConnection.addIceCandidate(candidate);
        }
    });
});