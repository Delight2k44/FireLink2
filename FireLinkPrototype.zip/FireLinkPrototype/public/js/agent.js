// FireLink Agent Dashboard JavaScript
const socket = io();
let agentMap = null;
let currentAgent = null;
let activeAlerts = [];
let demoDevices = [];
let alertMarkers = [];
let deviceMarkers = [];
let webrtcConnection = null;
let localStream = null;

document.addEventListener('DOMContentLoaded', function() {
    // Check if already logged in
    const token = localStorage.getItem('firelink_agent_token');
    if (token) {
        // Verify token and load dashboard
        verifyTokenAndLoadDashboard(token);
    }

    // Login form handler
    const loginForm = document.getElementById('loginForm');
    const logoutBtn = document.getElementById('logoutBtn');

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        login(email, password);
    });

    logoutBtn.addEventListener('click', logout);

    // Dashboard functionality
    const initiateCallBtn = document.getElementById('initiateCallBtn');
    const sendMessageBtn = document.getElementById('sendMessageBtn');
    const centerMapBtn = document.getElementById('centerMapBtn');
    const toggleSatelliteBtn = document.getElementById('toggleSatelliteBtn');

    initiateCallBtn.addEventListener('click', initiateCall);
    sendMessageBtn.addEventListener('click', sendMessage);
    centerMapBtn.addEventListener('click', centerMapOnAlerts);
    toggleSatelliteBtn.addEventListener('click', toggleSatelliteView);

    // Call modal handlers
    const endCallBtn = document.getElementById('endCallBtn');
    const muteBtn = document.getElementById('muteBtn');
    
    if (endCallBtn) endCallBtn.addEventListener('click', endCall);
    if (muteBtn) muteBtn.addEventListener('click', toggleMute);

    // Socket.IO connection
    socket.on('connect', function() {
        console.log('Connected to FireLink agent system');
        if (currentAgent) {
            socket.emit('join_agents');
        }
    });

    // Listen for new alerts
    socket.on('new_alert', function(data) {
        console.log('Agent received new alert:', data);
        handleNewAlert(data);
    });

    // Listen for device responses
    socket.on('device_response', function(data) {
        console.log('Device response:', data);
        handleDeviceResponse(data);
    });

    // WebRTC signaling
    socket.on('webrtc_answer', handleWebRTCAnswer);
    socket.on('webrtc_ice', handleWebRTCIceCandidate);

    // Functions
    function login(email, password) {
        const loginError = document.getElementById('loginError');
        loginError.textContent = '';

        fetch('/api/agents/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                localStorage.setItem('firelink_agent_token', data.token);
                currentAgent = data.agent;
                showDashboard();
                initializeDashboard();
            } else {
                loginError.textContent = data.error || 'Login failed';
            }
        })
        .catch(error => {
            console.error('Login error:', error);
            loginError.textContent = 'Login failed. Please try again.';
        });
    }

    function verifyTokenAndLoadDashboard(token) {
        // In a real app, verify token with server
        // For demo, just parse the token
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            currentAgent = {
                id: payload.id,
                email: payload.email,
                name: 'Demo Agent',
                lat: -33.9249,
                lng: 18.4241
            };
            showDashboard();
            initializeDashboard();
        } catch (error) {
            localStorage.removeItem('firelink_agent_token');
        }
    }

    function logout() {
        localStorage.removeItem('firelink_agent_token');
        currentAgent = null;
        showLogin();
    }

    function showLogin() {
        document.getElementById('loginScreen').style.display = 'flex';
        document.getElementById('dashboardScreen').style.display = 'none';
    }

    function showDashboard() {
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('dashboardScreen').style.display = 'block';
        
        if (currentAgent) {
            document.getElementById('agentName').textContent = currentAgent.name || currentAgent.email;
        }
    }

    function initializeDashboard() {
        // Initialize map
        initializeAgentMap();
        
        // Load demo devices
        loadDemoDevices();
        
        // Load existing alerts
        loadActiveAlerts();
        
        // Join agents socket room
        socket.emit('join_agents');
    }

    function initializeAgentMap() {
        // Cape Town coordinates for demo
        const capeTown = [-33.9249, 18.4241];
        
        agentMap = L.map('agentMap').setView(capeTown, 14);
        
        // Default satellite view
        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: '© Esri'
        }).addTo(agentMap);

        // Add agent marker
        if (currentAgent) {
            const agentIcon = L.divIcon({
                html: '<div class="agent-marker">👨‍🚒</div>',
                className: 'custom-div-icon',
                iconSize: [30, 30],
                iconAnchor: [15, 15]
            });

            L.marker([currentAgent.lat, currentAgent.lng], { icon: agentIcon })
                .bindPopup(`<b>Agent Position</b><br>${currentAgent.name}`)
                .addTo(agentMap);
        }
    }

    function loadDemoDevices() {
        fetch('/api/demo/devices')
            .then(response => response.json())
            .then(devices => {
                demoDevices = devices;
                displayAgentDevicesGrid(devices);
                addDevicesToAgentMap(devices);
                updateDashboardStats();
            });
    }

    function loadActiveAlerts() {
        fetch('/api/alerts')
            .then(response => response.json())
            .then(alerts => {
                activeAlerts = alerts.filter(alert => alert.status === 'active');
                displayActiveAlerts(activeAlerts);
                addAlertsToMap(activeAlerts);
                updateDashboardStats();
            });
    }

    function displayActiveAlerts(alerts) {
        const alertsList = document.getElementById('agentAlertsList');
        
        if (alerts.length === 0) {
            alertsList.innerHTML = `
                <div class="no-alerts">
                    <p>No active alerts.</p>
                    <p class="demo-hint">System monitoring ${demoDevices.length} community devices.</p>
                </div>
            `;
            return;
        }

        alertsList.innerHTML = '';
        alerts.forEach(alert => {
            const alertCard = document.createElement('div');
            alertCard.className = 'alert-card';
            alertCard.innerHTML = `
                <div class="alert-header">
                    <div class="alert-severity">EMERGENCY</div>
                    <div class="alert-time">${new Date(alert.created_at).toLocaleTimeString()}</div>
                </div>
                <div class="alert-info">
                    <h3>House Fire Alert #${alert.id}</h3>
                    <p><strong>Reporter:</strong> ${alert.reporter_name}</p>
                    <p><strong>Phone:</strong> ${alert.reporter_phone}</p>
                    <p><strong>Location:</strong> ${alert.lat.toFixed(6)}, ${alert.lng.toFixed(6)}</p>
                    <p><strong>Radius:</strong> ${alert.radius}m</p>
                    <p><strong>Message:</strong> ${alert.message}</p>
                </div>
                <div class="alert-actions">
                    <button class="btn-primary" onclick="focusOnAlert(${alert.id}, ${alert.lat}, ${alert.lng})">Focus Map</button>
                    <button class="btn-success" onclick="initiateCallToReporter(${alert.id})">Call Reporter</button>
                </div>
            `;
            alertsList.appendChild(alertCard);
        });

        // Enable communication buttons
        document.getElementById('initiateCallBtn').disabled = false;
        document.getElementById('sendMessageBtn').disabled = false;
    }

    function displayAgentDevicesGrid(devices) {
        const grid = document.getElementById('agentDevicesGrid');
        grid.innerHTML = '';

        devices.forEach(device => {
            const deviceCard = document.createElement('div');
            deviceCard.className = `device-card ${device.status}`;
            deviceCard.id = `agent-device-${device.id}`;
            deviceCard.innerHTML = `
                <span class="device-icon">📱</span>
                <div class="device-name">${device.name}</div>
                <div class="device-distance">${device.distance}m</div>
                <div class="device-status status-${device.status}">${device.status}</div>
            `;
            grid.appendChild(deviceCard);
        });
    }

    function addDevicesToAgentMap(devices) {
        devices.forEach(device => {
            const icon = L.divIcon({
                html: `<div class="device-marker device-${device.status}">📱</div>`,
                className: 'custom-div-icon',
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            });

            const marker = L.marker([device.lat, device.lng], { icon })
                .bindPopup(`<b>${device.name}</b><br>Distance: ${device.distance}m<br>Status: ${device.status}`)
                .addTo(agentMap);

            deviceMarkers.push({ id: device.id, marker });
        });
    }

    function addAlertsToMap(alerts) {
        alerts.forEach(alert => {
            // Add alert marker
            const alertIcon = L.divIcon({
                html: '<div class="alert-marker">🚨</div>',
                className: 'custom-div-icon',
                iconSize: [30, 30],
                iconAnchor: [15, 15]
            });

            const alertMarker = L.marker([alert.lat, alert.lng], { icon: alertIcon })
                .bindPopup(`<b>EMERGENCY #${alert.id}</b><br>${alert.reporter_name}<br>${alert.message}`)
                .addTo(agentMap);

            // Add radius circle
            const radiusCircle = L.circle([alert.lat, alert.lng], {
                radius: alert.radius,
                color: 'red',
                fillColor: '#f03',
                fillOpacity: 0.2
            }).addTo(agentMap);

            alertMarkers.push({ alert, marker: alertMarker, circle: radiusCircle });
        });
    }

    function handleNewAlert(data) {
        const alert = data.alert;
        activeAlerts.push(alert);
        
        // Update displays
        displayActiveAlerts(activeAlerts);
        
        // Add to map
        const alertIcon = L.divIcon({
            html: '<div class="alert-marker">🚨</div>',
            className: 'custom-div-icon',
            iconSize: [30, 30],
            iconAnchor: [15, 15]
        });

        const alertMarker = L.marker([alert.lat, alert.lng], { icon: alertIcon })
            .bindPopup(`<b>EMERGENCY #${alert.id}</b><br>${alert.reporter_name}<br>${alert.message}`)
            .addTo(agentMap);

        const radiusCircle = L.circle([alert.lat, alert.lng], {
            radius: alert.radius,
            color: 'red',
            fillColor: '#f03',
            fillOpacity: 0.2
        }).addTo(agentMap);

        alertMarkers.push({ alert, marker: alertMarker, circle: radiusCircle });

        // Update stats
        updateDashboardStats();
        
        // Center map on new alert
        agentMap.setView([alert.lat, alert.lng], 16);
    }

    function handleDeviceResponse(data) {
        console.log('Device response received:', data);
        
        // Update device in grid
        updateAgentDeviceStatus(data.deviceId, data.status);
        
        // Update stats
        updateDashboardStats();
    }

    function updateAgentDeviceStatus(deviceId, status) {
        // Update device card
        const deviceCard = document.getElementById(`agent-device-${deviceId}`);
        if (deviceCard) {
            deviceCard.className = `device-card ${status}`;
            const statusElement = deviceCard.querySelector('.device-status');
            statusElement.className = `device-status status-${status}`;
            statusElement.textContent = status;
        }

        // Update device in data
        const device = demoDevices.find(d => d.id == deviceId);
        if (device) {
            device.status = status;
        }

        // Update map marker
        const deviceMarker = deviceMarkers.find(m => m.id == deviceId);
        if (deviceMarker) {
            const newIcon = L.divIcon({
                html: `<div class="device-marker device-${status}">📱</div>`,
                className: 'custom-div-icon',
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            });
            deviceMarker.marker.setIcon(newIcon);
        }
    }

    function updateDashboardStats() {
        const totalAlerts = document.getElementById('totalAlerts');
        const devicesResponded = document.getElementById('devicesResponded');
        const avgResponseTime = document.getElementById('avgResponseTime');
        
        totalAlerts.textContent = activeAlerts.length;
        devicesResponded.textContent = demoDevices.filter(d => d.status === 'responded').length;
        avgResponseTime.textContent = '45s'; // Demo value
    }

    // Communication functions
    async function initiateCall() {
        if (activeAlerts.length === 0) {
            alert('No active alerts to call');
            return;
        }

        try {
            // Initialize WebRTC
            localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            webrtcConnection = new RTCPeerConnection({
                iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
            });

            localStream.getTracks().forEach(track => {
                webrtcConnection.addTrack(track, localStream);
            });

            webrtcConnection.ontrack = function(event) {
                const remoteAudio = document.getElementById('remoteAudio');
                remoteAudio.srcObject = event.streams[0];
            };

            webrtcConnection.onicecandidate = function(event) {
                if (event.candidate) {
                    socket.emit('webrtc_ice', event.candidate);
                }
            };

            // Create offer
            const offer = await webrtcConnection.createOffer();
            await webrtcConnection.setLocalDescription(offer);
            
            // Send offer to reporter
            socket.emit('webrtc_offer', offer);
            
            // Show call modal
            showCallModal();
            
        } catch (error) {
            console.error('Error initiating call:', error);
            alert('Failed to initiate call: ' + error.message);
        }
    }

    function sendMessage() {
        alert('Message feature would integrate with SMS/WhatsApp in production');
    }

    function centerMapOnAlerts() {
        if (activeAlerts.length > 0) {
            const alert = activeAlerts[0];
            agentMap.setView([alert.lat, alert.lng], 16);
        }
    }

    function toggleSatelliteView() {
        // This would toggle between satellite and street view
        alert('Satellite view toggle - in production this would switch map layers');
    }

    function showCallModal() {
        const callModal = document.getElementById('callModal');
        const callTarget = document.getElementById('callTarget');
        
        if (activeAlerts.length > 0) {
            callTarget.textContent = `Calling ${activeAlerts[0].reporter_name}...`;
        }
        
        callModal.style.display = 'block';
        
        // Start call timer
        startCallTimer();
    }

    function endCall() {
        if (webrtcConnection) {
            webrtcConnection.close();
            webrtcConnection = null;
        }
        
        if (localStream) {
            localStream.getTracks().forEach(track => track.stop());
            localStream = null;
        }
        
        const callModal = document.getElementById('callModal');
        callModal.style.display = 'none';
    }

    function toggleMute() {
        if (localStream) {
            const audioTrack = localStream.getAudioTracks()[0];
            audioTrack.enabled = !audioTrack.enabled;
            
            const muteBtn = document.getElementById('muteBtn');
            muteBtn.textContent = audioTrack.enabled ? '🔇 Mute' : '🔊 Unmute';
        }
    }

    function startCallTimer() {
        let seconds = 0;
        const timerInterval = setInterval(() => {
            seconds++;
            const mins = Math.floor(seconds / 60);
            const secs = seconds % 60;
            const callTimer = document.querySelector('.call-timer');
            if (callTimer) {
                callTimer.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
            } else {
                clearInterval(timerInterval);
            }
        }, 1000);
    }

    // WebRTC handlers
    async function handleWebRTCAnswer(answer) {
        if (webrtcConnection) {
            await webrtcConnection.setRemoteDescription(answer);
        }
    }

    async function handleWebRTCIceCandidate(candidate) {
        if (webrtcConnection) {
            await webrtcConnection.addIceCandidate(candidate);
        }
    }

    // Global functions for button clicks
    window.focusOnAlert = function(alertId, lat, lng) {
        agentMap.setView([lat, lng], 18);
    };

    window.initiateCallToReporter = function(alertId) {
        initiateCall();
    };
});