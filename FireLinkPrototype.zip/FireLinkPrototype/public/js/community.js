// FireLink Community JavaScript
const socket = io();
let communityMap = null;
let alertMarkers = [];
let deviceMarkers = [];
let currentAlerts = [];
let demoDevices = [];
let panicAudio = null;

document.addEventListener('DOMContentLoaded', function() {
    // Initialize map
    initializeCommunityMap();
    
    // Initialize audio
    panicAudio = document.getElementById('panicAudio');
    
    // Load demo devices
    loadDemoDevices();
    
    // Modal elements
    const ringtoneModal = document.getElementById('ringtoneModal');
    const openMapBtn = document.getElementById('openMapBtn');
    const markEnRouteBtn = document.getElementById('markEnRouteBtn');
    const dismissAlertBtn = document.getElementById('dismissAlertBtn');

    // Modal handlers
    openMapBtn.addEventListener('click', function() {
        // Open Google Maps with alert location
        const alertData = ringtoneModal.dataset.alertData;
        if (alertData) {
            const alert = JSON.parse(alertData);
            const url = `https://maps.google.com/maps?q=${alert.lat},${alert.lng}`;
            window.open(url, '_blank');
        }
        hideRingtoneModal();
    });

    markEnRouteBtn.addEventListener('click', function() {
        const deviceId = ringtoneModal.dataset.deviceId;
        const alertId = ringtoneModal.dataset.alertId;
        
        if (deviceId && alertId) {
            // Update device status
            socket.emit('device_respond', {
                deviceId: parseInt(deviceId),
                status: 'responded',
                alertId: parseInt(alertId)
            });
            
            // Update UI
            updateDeviceStatus(deviceId, 'responded');
            addTimelineEntry(`Device ${deviceId} marked "I am coming"`);
        }
        
        hideRingtoneModal();
    });

    dismissAlertBtn.addEventListener('click', function() {
        hideRingtoneModal();
    });

    // Socket.IO connection
    socket.on('connect', function() {
        console.log('Connected to FireLink community');
        socket.emit('join_community');
    });

    // Listen for new alerts
    socket.on('new_alert', function(data) {
        console.log('New alert received:', data);
        handleNewAlert(data);
    });

    // Listen for ringtone events
    socket.on('play_ringtone', function(data) {
        console.log('Ringtone event:', data);
        handleRingtoneEvent(data);
    });

    // Initialize functions
    function initializeCommunityMap() {
        // Cape Town coordinates for demo
        const capeTown = [-33.9249, 18.4241];
        
        communityMap = L.map('communityMap').setView(capeTown, 15);
        
        // Use satellite imagery
        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: '© Esri'
        }).addTo(communityMap);

        // Add initial demo message
        const popup = L.popup()
            .setLatLng(capeTown)
            .setContent('FireLink Community Alert System<br>Demo area with 20 simulated devices')
            .openOn(communityMap);
    }

    function loadDemoDevices() {
        fetch('/api/demo/devices')
            .then(response => response.json())
            .then(devices => {
                demoDevices = devices;
                displayDevicesGrid(devices);
                addDevicesToMap(devices);
                updateStats();
            });
    }

    function displayDevicesGrid(devices) {
        const grid = document.getElementById('devicesGrid');
        grid.innerHTML = '';

        devices.forEach(device => {
            const deviceCard = document.createElement('div');
            deviceCard.className = `device-card ${device.status}`;
            deviceCard.id = `device-${device.id}`;
            deviceCard.innerHTML = `
                <span class="device-icon">📱</span>
                <div class="device-name">${device.name}</div>
                <div class="device-distance">${device.distance}m away</div>
                <div class="device-status status-${device.status}">${device.status}</div>
            `;
            grid.appendChild(deviceCard);
        });
    }

    function addDevicesToMap(devices) {
        devices.forEach(device => {
            const icon = L.divIcon({
                html: `<div class="device-marker device-${device.status}">📱</div>`,
                className: 'custom-div-icon',
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            });

            const marker = L.marker([device.lat, device.lng], { icon })
                .bindPopup(`<b>${device.name}</b><br>${device.distance}m<br>Status: ${device.status}`)
                .addTo(communityMap);

            deviceMarkers.push({ id: device.id, marker });
        });
    }

    function handleNewAlert(data) {
        const alert = data.alert;
        currentAlerts.push(alert);
        
        // Add to alerts list
        displayAlert(alert);
        
        // Add to map
        addAlertToMap(alert);
        
        // Update stats
        updateStats();
        
        // Add timeline entry
        addTimelineEntry(`SOS sent by ${alert.reporter_name} - ${data.devicesInRange ? data.devicesInRange.length : 0} devices pinged`);
    }

    function handleRingtoneEvent(data) {
        console.log('Playing ringtone for device:', data.deviceId);
        
        // Update device visual state
        updateDeviceStatus(data.deviceId, 'pinged');
        
        // Show ringtone modal for one of the devices (simulating user's device)
        if (Math.random() < 0.3) { // 30% chance to simulate this device being pinged
            showRingtoneModal(data);
        }
        
        // Add timeline entry
        addTimelineEntry(`Device ${data.deviceId} pinged - ${data.distance}m from alert`);
    }

    function updateDeviceStatus(deviceId, status) {
        // Update device card
        const deviceCard = document.getElementById(`device-${deviceId}`);
        if (deviceCard) {
            deviceCard.className = `device-card ${status}`;
            const statusElement = deviceCard.querySelector('.device-status');
            statusElement.className = `device-status status-${status}`;
            statusElement.textContent = status;
        }

        // Update device in data
        const device = demoDevices.find(d => d.id == deviceId);
        if (device) {
            device.status = status;
        }

        // Update map marker
        const deviceMarker = deviceMarkers.find(m => m.id == deviceId);
        if (deviceMarker) {
            const newIcon = L.divIcon({
                html: `<div class="device-marker device-${status}">📱</div>`,
                className: 'custom-div-icon',
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            });
            deviceMarker.marker.setIcon(newIcon);
        }
    }

    function displayAlert(alert) {
        const alertsList = document.getElementById('activeAlertsList');
        
        // Remove "no alerts" message
        const noAlerts = alertsList.querySelector('.no-alerts');
        if (noAlerts) {
            noAlerts.remove();
        }

        const alertCard = document.createElement('div');
        alertCard.className = 'alert-card';
        alertCard.innerHTML = `
            <div class="alert-header">
                <div class="alert-severity">EMERGENCY</div>
                <div class="alert-time">${new Date(alert.created_at).toLocaleTimeString()}</div>
            </div>
            <div class="alert-info">
                <h3>House Fire Alert</h3>
                <p><strong>Reporter:</strong> ${alert.reporter_name}</p>
                <p><strong>Location:</strong> ${alert.lat.toFixed(6)}, ${alert.lng.toFixed(6)}</p>
                <p><strong>Message:</strong> ${alert.message}</p>
                <p><strong>Radius:</strong> ${alert.radius}m</p>
            </div>
            <div class="alert-actions">
                <button class="btn-primary" onclick="openAlertMap(${alert.lat}, ${alert.lng})">View on Map</button>
                <button class="btn-secondary" onclick="shareLocation(${alert.lat}, ${alert.lng})">Share Location</button>
            </div>
        `;
        
        alertsList.appendChild(alertCard);
    }

    function addAlertToMap(alert) {
        // Add alert marker
        const alertIcon = L.divIcon({
            html: '<div class="alert-marker">🚨</div>',
            className: 'custom-div-icon',
            iconSize: [30, 30],
            iconAnchor: [15, 15]
        });

        const alertMarker = L.marker([alert.lat, alert.lng], { icon: alertIcon })
            .bindPopup(`<b>EMERGENCY ALERT</b><br>${alert.reporter_name}<br>${alert.message}`)
            .addTo(communityMap);

        // Add radius circle
        const radiusCircle = L.circle([alert.lat, alert.lng], {
            radius: alert.radius,
            color: 'red',
            fillColor: '#f03',
            fillOpacity: 0.2
        }).addTo(communityMap);

        alertMarkers.push({ alert, marker: alertMarker, circle: radiusCircle });

        // Center map on alert
        communityMap.setView([alert.lat, alert.lng], 16);
    }

    function showRingtoneModal(data) {
        const modal = document.getElementById('ringtoneModal');
        const alertMessage = document.getElementById('alertMessage');
        const alertDistance = document.getElementById('alertDistance');
        
        alertMessage.textContent = `Emergency alert from ${data.reporter}`;
        alertDistance.textContent = `${data.distance}m from your location`;
        
        modal.dataset.deviceId = data.deviceId;
        modal.dataset.alertId = data.alertId;
        modal.dataset.alertData = JSON.stringify(data);
        
        modal.style.display = 'block';
        
        // Play panic ringtone
        if (panicAudio && document.getElementById('enableSound').checked) {
            panicAudio.play().catch(e => console.log('Audio play failed:', e));
        }
    }

    function hideRingtoneModal() {
        const modal = document.getElementById('ringtoneModal');
        modal.style.display = 'none';
        
        // Stop panic ringtone
        if (panicAudio) {
            panicAudio.pause();
            panicAudio.currentTime = 0;
        }
    }

    function addTimelineEntry(message) {
        const timeline = document.getElementById('alertTimeline');
        const timelineItem = document.createElement('div');
        timelineItem.className = 'timeline-item';
        
        const now = new Date();
        const timeStr = now.toLocaleTimeString();
        
        timelineItem.innerHTML = `
            <div class="timeline-time">${timeStr}</div>
            <div class="timeline-content">${message}</div>
        `;
        
        timeline.appendChild(timelineItem);
        timeline.scrollTop = timeline.scrollHeight;
    }

    function updateStats() {
        const activeAlerts = document.getElementById('activeAlerts');
        const devicesOnline = document.getElementById('devicesOnline');
        
        activeAlerts.textContent = `${currentAlerts.length} Active Alerts`;
        devicesOnline.textContent = `${demoDevices.length} Devices Online`;
    }

    // Global functions for button clicks
    window.openAlertMap = function(lat, lng) {
        communityMap.setView([lat, lng], 18);
    };

    window.shareLocation = function(lat, lng) {
        if (navigator.share) {
            navigator.share({
                title: 'FireLink Emergency Alert',
                text: 'Emergency alert location',
                url: `https://maps.google.com/maps?q=${lat},${lng}`
            });
        } else {
            // Fallback
            navigator.clipboard.writeText(`${lat},${lng}`)
                .then(() => alert('Location copied to clipboard'))
                .catch(() => alert(`Location: ${lat},${lng}`));
        }
    };

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('ringtoneModal');
        if (event.target === modal) {
            hideRingtoneModal();
        }
    });
});