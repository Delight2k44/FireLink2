const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Cache-Control headers for development
app.use((req, res, next) => {
  res.header('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.header('Pragma', 'no-cache');
  res.header('Expires', '0');
  next();
});

// Initialize SQLite database
const db = new sqlite3.Database('./firelink.db');

// Create tables and seed data
db.serialize(() => {
  // Agents table
  db.run(`CREATE TABLE IF NOT EXISTS agents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    name TEXT,
    lat REAL,
    lng REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Alerts table
  db.run(`CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reporter_name TEXT,
    reporter_phone TEXT,
    lat REAL,
    lng REAL,
    message TEXT,
    status TEXT DEFAULT 'active',
    radius INTEGER DEFAULT 80,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME
  )`);

  // Seed agent user
  const agentPassword = bcrypt.hashSync('123456789', 10);
  db.run(`INSERT OR IGNORE INTO agents (email, password, name, lat, lng) 
          VALUES (?, ?, ?, ?, ?)`, 
    ['Delightchetter@gmail.com', agentPassword, 'Demo Agent', -33.9249, 18.4241]);
});

// Simulated device data for demo
const demoDevices = [
  { id: 1, name: 'John\'s Phone', lat: -33.9249, lng: 18.4241, status: 'idle', distance: 0 },
  { id: 2, name: 'Sarah\'s Phone', lat: -33.9250, lng: 18.4242, status: 'idle', distance: 15 },
  { id: 3, name: 'Mike\'s Phone', lat: -33.9248, lng: 18.4240, status: 'idle', distance: 12 },
  { id: 4, name: 'Emma\'s Phone', lat: -33.9251, lng: 18.4245, status: 'idle', distance: 45 },
  { id: 5, name: 'David\'s Phone', lat: -33.9247, lng: 18.4239, status: 'idle', distance: 25 },
  { id: 6, name: 'Lisa\'s Phone', lat: -33.9252, lng: 18.4246, status: 'idle', distance: 65 },
  { id: 7, name: 'Tom\'s Phone', lat: -33.9246, lng: 18.4238, status: 'idle', distance: 35 },
  { id: 8, name: 'Anna\'s Phone', lat: -33.9253, lng: 18.4247, status: 'idle', distance: 75 },
  { id: 9, name: 'Chris\'s Phone', lat: -33.9245, lng: 18.4237, status: 'idle', distance: 42 },
  { id: 10, name: 'Kate\'s Phone', lat: -33.9254, lng: 18.4248, status: 'idle', distance: 85 },
  { id: 11, name: 'Alex\'s Phone', lat: -33.9244, lng: 18.4236, status: 'idle', distance: 55 },
  { id: 12, name: 'Sophie\'s Phone', lat: -33.9255, lng: 18.4249, status: 'idle', distance: 95 },
  { id: 13, name: 'Ryan\'s Phone', lat: -33.9243, lng: 18.4235, status: 'idle', distance: 68 },
  { id: 14, name: 'Zoe\'s Phone', lat: -33.9256, lng: 18.4250, status: 'idle', distance: 105 },
  { id: 15, name: 'Jake\'s Phone', lat: -33.9242, lng: 18.4234, status: 'idle', distance: 78 },
  { id: 16, name: 'Mia\'s Phone', lat: -33.9257, lng: 18.4251, status: 'idle', distance: 115 },
  { id: 17, name: 'Noah\'s Phone', lat: -33.9241, lng: 18.4233, status: 'idle', distance: 88 },
  { id: 18, name: 'Lily\'s Phone', lat: -33.9258, lng: 18.4252, status: 'idle', distance: 125 },
  { id: 19, name: 'Owen\'s Phone', lat: -33.9240, lng: 18.4232, status: 'idle', distance: 98 },
  { id: 20, name: 'Grace\'s Phone', lat: -33.9259, lng: 18.4253, status: 'idle', distance: 135 }
];

// Haversine distance calculation
function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = lat1 * Math.PI/180;
  const φ2 = lat2 * Math.PI/180;
  const Δφ = (lat2-lat1) * Math.PI/180;
  const Δλ = (lon2-lon1) * Math.PI/180;

  const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
          Math.cos(φ1) * Math.cos(φ2) *
          Math.sin(Δλ/2) * Math.sin(Δλ/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

  return R * c; // Distance in meters
}

// API Routes
app.post('/api/alerts', (req, res) => {
  const { reporter_name, reporter_phone, lat, lng, message, radius } = req.body;
  
  db.run(`INSERT INTO alerts (reporter_name, reporter_phone, lat, lng, message, radius) 
          VALUES (?, ?, ?, ?, ?, ?)`,
    [reporter_name, reporter_phone, lat, lng, message, radius || 80],
    function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      const alertId = this.lastID;
      const alert = {
        id: alertId,
        reporter_name,
        reporter_phone,
        lat,
        lng,
        message,
        radius: radius || 80,
        created_at: new Date().toISOString(),
        status: 'active'
      };

      // Calculate which devices are in range
      const devicesInRange = demoDevices.map(device => {
        const distance = getDistance(lat, lng, device.lat, device.lng);
        return { ...device, distance, inRange: distance <= (radius || 80) };
      });

      // Emit to community and agents
      io.to('community').emit('new_alert', {
        alert,
        devicesInRange: devicesInRange.filter(d => d.inRange)
      });

      io.to('agents').emit('new_alert', {
        alert,
        devicesInRange,
        totalPinged: devicesInRange.filter(d => d.inRange).length
      });

      // Trigger ringtone on devices in range
      setTimeout(() => {
        devicesInRange.filter(d => d.inRange).forEach(device => {
          io.to('community').emit('play_ringtone', {
            deviceId: device.id,
            alertId,
            distance: Math.round(device.distance),
            reporter: reporter_name
          });
        });
      }, 1000);

      res.json({
        success: true,
        alert,
        devicesInRange: devicesInRange.filter(d => d.inRange),
        totalPinged: devicesInRange.filter(d => d.inRange).length
      });
    });
});

app.get('/api/alerts/:id', (req, res) => {
  const alertId = req.params.id;
  
  db.get('SELECT * FROM alerts WHERE id = ?', [alertId], (err, row) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (!row) {
      return res.status(404).json({ error: 'Alert not found' });
    }
    
    res.json(row);
  });
});

app.get('/api/alerts', (req, res) => {
  db.all('SELECT * FROM alerts ORDER BY created_at DESC LIMIT 50', (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(rows);
  });
});

app.post('/api/agents/login', (req, res) => {
  const { email, password } = req.body;
  
  db.get('SELECT * FROM agents WHERE email = ?', [email], async (err, agent) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    if (!agent || !bcrypt.compareSync(password, agent.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign(
      { id: agent.id, email: agent.email },
      process.env.JWT_SECRET || 'firelink-demo-secret',
      { expiresIn: '24h' }
    );
    
    res.json({
      success: true,
      token,
      agent: {
        id: agent.id,
        email: agent.email,
        name: agent.name,
        lat: agent.lat,
        lng: agent.lng
      }
    });
  });
});

app.get('/api/demo/devices', (req, res) => {
  res.json(demoDevices);
});

app.post('/api/devices/:id/respond', (req, res) => {
  const deviceId = parseInt(req.params.id);
  const { status, alertId } = req.body;
  
  // Update device status in demo data
  const device = demoDevices.find(d => d.id === deviceId);
  if (device) {
    device.status = status;
    
    // Emit to agents
    io.to('agents').emit('device_response', {
      deviceId,
      device,
      status,
      alertId,
      timestamp: new Date().toISOString()
    });
  }
  
  res.json({ success: true });
});

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('join_community', () => {
    socket.join('community');
    console.log('User joined community channel');
  });

  socket.on('join_agents', () => {
    socket.join('agents');
    console.log('Agent joined agents channel');
  });

  socket.on('webrtc_offer', (data) => {
    socket.broadcast.emit('webrtc_offer', data);
  });

  socket.on('webrtc_answer', (data) => {
    socket.broadcast.emit('webrtc_answer', data);
  });

  socket.on('webrtc_ice', (data) => {
    socket.broadcast.emit('webrtc_ice', data);
  });

  socket.on('device_respond', (data) => {
    const { deviceId, status, alertId } = data;
    const device = demoDevices.find(d => d.id === deviceId);
    if (device) {
      device.status = status;
      io.to('agents').emit('device_response', {
        deviceId,
        device,
        status,
        alertId,
        timestamp: new Date().toISOString()
      });
    }
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Serve HTML files
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/community', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'community.html'));
});

app.get('/agent', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'agent.html'));
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`FireLink server running on http://0.0.0.0:${PORT}`);
});