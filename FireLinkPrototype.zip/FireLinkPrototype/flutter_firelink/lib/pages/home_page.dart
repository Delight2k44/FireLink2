import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_firelink/services/socket_service.dart';
import 'package:flutter_firelink/services/location_service.dart';
import 'package:flutter_firelink/widgets/navigation_bar.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool enableSound = true;
  int alertRadius = 80;
  
  @override
  void initState() {
    super.initState();
    // Initialize services
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<SocketService>(context, listen: false).connect();
      Provider.of<LocationService>(context, listen: false).initialize();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          CustomNavigationBar(currentRoute: '/'),
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF667eea), Color(0xFF764ba2)],
                ),
              ),
              child: Container(
                margin: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.95),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 30,
                      offset: Offset(0, 0),
                    ),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.all(32),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '🔥 FireLink',
                        style: TextStyle(
                          fontSize: 48,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFDC2626),
                        ),
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Emergency Alert System',
                        style: TextStyle(
                          fontSize: 32,
                          color: Color(0xFFDC2626),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Press the button below if you need immediate help',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 48),
                      
                      // SOS Button
                      GestureDetector(
                        onTap: _triggerSOS,
                        child: Container(
                          width: 200,
                          height: 200,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Color(0xFFDC2626), Color(0xFFEF4444)],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFFDC2626).withOpacity(0.4),
                                blurRadius: 30,
                                offset: Offset(0, 10),
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'SOS',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 32,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'Emergency',
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.8),
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      SizedBox(height: 48),
                      
                      // Settings Section
                      Container(
                        padding: EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: Colors.grey[50],
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Settings',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.grey[800],
                              ),
                            ),
                            SizedBox(height: 16),
                            
                            // Sound toggle
                            Row(
                              children: [
                                Checkbox(
                                  value: enableSound,
                                  onChanged: (value) => setState(() => enableSound = value ?? true),
                                  activeColor: Color(0xFFDC2626),
                                ),
                                Expanded(
                                  child: Text(
                                    'Enable sound autoplay (tap to enable browser permission)',
                                    style: TextStyle(fontSize: 14),
                                  ),
                                ),
                              ],
                            ),
                            
                            SizedBox(height: 16),
                            
                            // Radius selection
                            Row(
                              children: [
                                Text(
                                  'Alert Radius:',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                SizedBox(width: 16),
                                DropdownButton<int>(
                                  value: alertRadius,
                                  items: [60, 80, 100].map((int value) {
                                    return DropdownMenuItem<int>(
                                      value: value,
                                      child: Text('${value} meters'),
                                    );
                                  }).toList(),
                                  onChanged: (value) => setState(() => alertRadius = value ?? 80),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      
                      SizedBox(height: 24),
                      
                      // Demo Notice
                      Container(
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Color(0xFFFEF3C7),
                          border: Border.all(color: Color(0xFFF59E0B)),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Column(
                          children: [
                            Text(
                              'Demo Notice:',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.orange[800],
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'This is a prototype demonstration. In production, this would integrate with real emergency services and hardware sensors.',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.orange[700],
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _triggerSOS() {
    _showConfirmDialog();
  }

  void _showConfirmDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              Text('⚠️'),
              SizedBox(width: 8),
              Text('Emergency Alert'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Are you sure you want to send an emergency alert?'),
              SizedBox(height: 8),
              Text(
                'This will notify nearby community members and emergency responders.',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _sendSOS();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFFDC2626),
              ),
              child: Text(
                'Send SOS Alert',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        );
      },
    );
  }

  void _sendSOS() async {
    try {
      final locationService = Provider.of<LocationService>(context, listen: false);
      final socketService = Provider.of<SocketService>(context, listen: false);
      
      // Get current location
      final position = await locationService.getCurrentLocation();
      
      // Send alert
      await socketService.sendAlert({
        'reporter_name': 'Flutter User',
        'reporter_phone': '+1-xxx-xxx-xxxx',
        'lat': position.latitude,
        'lng': position.longitude,
        'message': 'Emergency assistance needed - house fire suspected',
        'radius': alertRadius,
      });
      
      _showSuccessDialog(position.latitude, position.longitude);
    } catch (e) {
      _showErrorDialog(e.toString());
    }
  }

  void _showSuccessDialog(double lat, double lng) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.green),
              SizedBox(width: 8),
              Text('Help is on its way!'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Emergency alert sent successfully - neighbors and responders notified.'),
              SizedBox(height: 12),
              Text(
                'Your location: ${lat.toStringAsFixed(6)}, ${lng.toStringAsFixed(6)}',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text('ETA: Emergency responders estimated 5-8 minutes'),
              SizedBox(height: 8),
              Text(
                'This is a demo - in production, real emergency services would be contacted.',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }

  void _showErrorDialog(String error) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text('Failed to send alert: $error'),
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }
}