import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_firelink/services/socket_service.dart';
import 'package:flutter_firelink/services/location_service.dart';
import 'package:flutter_firelink/services/audio_service.dart';
import 'package:flutter_firelink/pages/home_page.dart';
import 'package:flutter_firelink/pages/community_page.dart';
import 'package:flutter_firelink/pages/agent_dashboard.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SocketService()),
        ChangeNotifierProvider(create: (_) => LocationService()),
        ChangeNotifierProvider(create: (_) => AudioService()),
      ],
      child: MaterialApp(
        title: 'FireLink Emergency System',
        theme: ThemeData(
          primarySwatch: Colors.red,
          primaryColor: Color(0xFFDC2626),
          fontFamily: 'Roboto',
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFFDC2626),
              foregroundColor: Colors.white,
              elevation: 3,
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ),
        initialRoute: '/',
        routes: {
          '/': (context) => HomePage(),
          '/community': (context) => CommunityPage(),
          '/agent': (context) => AgentDashboard(),
        },
      ),
    );
  }
}