import 'package:flutter/material.dart';

class CustomNavigationBar extends StatelessWidget {
  final String currentRoute;
  
  const CustomNavigationBar({Key? key, required this.currentRoute}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Colors.grey[300]!, width: 2)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Text(
                '🔥',
                style: TextStyle(fontSize: 24),
              ),
              SizedBox(width: 8),
              Text(
                'FireLink',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFFDC2626),
                ),
              ),
            ],
          ),
          Row(
            children: [
              _buildNavButton(context, 'SOS', '/', currentRoute == '/'),
              SizedBox(width: 24),
              _buildNavButton(context, 'Community', '/community', currentRoute == '/community'),
              SizedBox(width: 24),
              _buildNavButton(context, 'Agent', '/agent', currentRoute == '/agent'),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildNavButton(BuildContext context, String title, String route, bool isActive) {
    return GestureDetector(
      onTap: () {
        if (!isActive) {
          Navigator.pushReplacementNamed(context, route);
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? Color(0xFFDC2626).withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(
          title,
          style: TextStyle(
            color: isActive ? Color(0xFFDC2626) : Colors.grey[600],
            fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
            fontSize: 16,
          ),
        ),
      ),
    );
  }
}