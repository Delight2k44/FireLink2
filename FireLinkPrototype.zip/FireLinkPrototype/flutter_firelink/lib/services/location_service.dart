import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

class LocationService extends ChangeNotifier {
  Position? _currentPosition;
  bool _serviceEnabled = false;
  LocationPermission _permission = LocationPermission.denied;
  
  Position? get currentPosition => _currentPosition;
  bool get serviceEnabled => _serviceEnabled;
  LocationPermission get permission => _permission;
  
  Future<void> initialize() async {
    await _checkLocationService();
    await _requestPermission();
  }
  
  Future<void> _checkLocationService() async {
    _serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!_serviceEnabled) {
      print('Location services are disabled.');
    }
    notifyListeners();
  }
  
  Future<void> _requestPermission() async {
    _permission = await Geolocator.checkPermission();
    if (_permission == LocationPermission.denied) {
      _permission = await Geolocator.requestPermission();
      if (_permission == LocationPermission.denied) {
        print('Location permissions are denied');
        return;
      }
    }
    
    if (_permission == LocationPermission.deniedForever) {
      print('Location permissions are permanently denied.');
      return;
    }
    
    notifyListeners();
  }
  
  Future<Position> getCurrentLocation() async {
    if (!_serviceEnabled) {
      throw Exception('Location services are disabled.');
    }
    
    if (_permission == LocationPermission.denied || 
        _permission == LocationPermission.deniedForever) {
      throw Exception('Location permissions are denied.');
    }
    
    try {
      _currentPosition = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 10),
      );
      notifyListeners();
      return _currentPosition!;
    } catch (e) {
      // Fallback to Cape Town coordinates for demo
      print('Could not get location, using demo coordinates: $e');
      _currentPosition = Position(
        latitude: -33.9249,
        longitude: 18.4241,
        timestamp: DateTime.now(),
        accuracy: 0,
        altitude: 0,
        altitudeAccuracy: 0,
        heading: 0,
        headingAccuracy: 0,
        speed: 0,
        speedAccuracy: 0,
      );
      notifyListeners();
      return _currentPosition!;
    }
  }
  
  double calculateDistance(double startLat, double startLng, double endLat, double endLng) {
    return Geolocator.distanceBetween(startLat, startLng, endLat, endLng);
  }
}