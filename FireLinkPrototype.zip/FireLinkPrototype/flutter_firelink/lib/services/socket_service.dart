import 'package:flutter/foundation.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:http/http.dart' as http;
import 'dart:convert';

class SocketService extends ChangeNotifier {
  static const String serverUrl = kDebugMode 
    ? 'http://localhost:5000' 
    : 'https://your-production-url.com'; // Replace with your production URL
    
  IO.Socket? _socket;
  bool _isConnected = false;
  List<Map<String, dynamic>> _alerts = [];
  List<Map<String, dynamic>> _devices = [];
  
  bool get isConnected => _isConnected;
  List<Map<String, dynamic>> get alerts => _alerts;
  List<Map<String, dynamic>> get devices => _devices;
  
  void connect() {
    try {
      _socket = IO.io(serverUrl, <String, dynamic>{
        'transports': ['websocket'],
        'autoConnect': false,
      });
      
      _socket?.connect();
      
      _socket?.on('connect', (_) {
        print('Connected to FireLink server');
        _isConnected = true;
        _socket?.emit('join_community');
        notifyListeners();
      });
      
      _socket?.on('disconnect', (_) {
        print('Disconnected from FireLink server');
        _isConnected = false;
        notifyListeners();
      });
      
      _socket?.on('new_alert', (data) {
        print('New alert received: $data');
        _handleNewAlert(data);
      });
      
      _socket?.on('play_ringtone', (data) {
        print('Ringtone event: $data');
        _handleRingtoneEvent(data);
      });
      
      _socket?.on('device_response', (data) {
        print('Device response: $data');
        _handleDeviceResponse(data);
      });
      
    } catch (e) {
      print('Socket connection error: $e');
    }
  }
  
  void disconnect() {
    _socket?.disconnect();
    _socket?.dispose();
    _isConnected = false;
    notifyListeners();
  }
  
  Future<Map<String, dynamic>> sendAlert(Map<String, dynamic> alertData) async {
    try {
      final response = await http.post(
        Uri.parse('$serverUrl/api/alerts'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(alertData),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data;
      } else {
        throw Exception('Failed to send alert: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }
  
  Future<List<Map<String, dynamic>>> loadDemoDevices() async {
    try {
      final response = await http.get(Uri.parse('$serverUrl/api/demo/devices'));
      
      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        _devices = data.cast<Map<String, dynamic>>();
        notifyListeners();
        return _devices;
      } else {
        throw Exception('Failed to load devices');
      }
    } catch (e) {
      print('Error loading devices: $e');
      return [];
    }
  }
  
  Future<Map<String, dynamic>> agentLogin(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$serverUrl/api/agents/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': password}),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          _socket?.emit('join_agents');
        }
        return data;
      } else {
        final error = jsonDecode(response.body);
        throw Exception(error['error'] ?? 'Login failed');
      }
    } catch (e) {
      throw Exception('Login error: $e');
    }
  }
  
  void respondToAlert(int deviceId, String status, int alertId) {
    _socket?.emit('device_respond', {
      'deviceId': deviceId,
      'status': status,
      'alertId': alertId,
    });
  }
  
  void _handleNewAlert(dynamic data) {
    if (data is Map<String, dynamic>) {
      final alert = data['alert'];
      if (alert != null) {
        _alerts.add(alert);
        notifyListeners();
      }
    }
  }
  
  void _handleRingtoneEvent(dynamic data) {
    if (data is Map<String, dynamic>) {
      // Find device and update its status
      final deviceId = data['deviceId'];
      final deviceIndex = _devices.indexWhere((d) => d['id'] == deviceId);
      if (deviceIndex != -1) {
        _devices[deviceIndex]['status'] = 'pinged';
        notifyListeners();
      }
    }
  }
  
  void _handleDeviceResponse(dynamic data) {
    if (data is Map<String, dynamic>) {
      final deviceId = data['deviceId'];
      final status = data['status'];
      final deviceIndex = _devices.indexWhere((d) => d['id'] == deviceId);
      if (deviceIndex != -1) {
        _devices[deviceIndex]['status'] = status;
        notifyListeners();
      }
    }
  }
  
  @override
  void dispose() {
    disconnect();
    super.dispose();
  }
}