import 'package:flutter/foundation.dart';
import 'package:audioplayers/audioplayers.dart';

class AudioService extends ChangeNotifier {
  late AudioPlayer _audioPlayer;
  bool _isPlaying = false;
  bool _soundEnabled = true;
  
  bool get isPlaying => _isPlaying;
  bool get soundEnabled => _soundEnabled;
  
  AudioService() {
    _audioPlayer = AudioPlayer();
    _setupAudioPlayer();
  }
  
  void _setupAudioPlayer() {
    _audioPlayer.onPlayerStateChanged.listen((PlayerState state) {
      _isPlaying = state == PlayerState.playing;
      notifyListeners();
    });
  }
  
  void setSoundEnabled(bool enabled) {
    _soundEnabled = enabled;
    if (!enabled && _isPlaying) {
      stopPanicRingtone();
    }
    notifyListeners();
  }
  
  Future<void> playPanicRingtone() async {
    if (!_soundEnabled) return;
    
    try {
      // In a real app, this would be an actual audio file
      // For demo, we'll simulate the audio playback
      print('Playing panic ringtone...');
      
      // Uncomment the following lines when you have a real audio file:
      // await _audioPlayer.setSource(AssetSource('audio/panic.mp3'));
      // await _audioPlayer.setReleaseMode(ReleaseMode.loop);
      // await _audioPlayer.resume();
      
      _isPlaying = true;
      notifyListeners();
      
      // Simulate audio for demo (remove this in production)
      Future.delayed(Duration(seconds: 5), () {
        if (_isPlaying) {
          stopPanicRingtone();
        }
      });
      
    } catch (e) {
      print('Error playing panic ringtone: $e');
    }
  }
  
  Future<void> stopPanicRingtone() async {
    try {
      await _audioPlayer.stop();
      _isPlaying = false;
      notifyListeners();
      print('Panic ringtone stopped');
    } catch (e) {
      print('Error stopping panic ringtone: $e');
    }
  }
  
  Future<void> playNotificationSound() async {
    if (!_soundEnabled) return;
    
    try {
      // Play a short notification sound
      // In production, use AssetSource('audio/notification.mp3')
      print('Playing notification sound...');
    } catch (e) {
      print('Error playing notification sound: $e');
    }
  }
  
  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}