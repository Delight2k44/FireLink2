# FireLink Emergency Alert System

## Overview

FireLink is a community-based emergency alert system that enables rapid response coordination through real-time communication and location services. The system consists of both a Node.js web application and a Flutter mobile/web app, providing comprehensive emergency response capabilities including SOS alerts, community coordination, agent dashboards, and real-time communication via WebSocket/Socket.IO.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Multi-Platform Approach**: Dual implementation strategy with HTML/PWA and Flutter projects providing identical functionality
- **Responsive Design**: Mobile-first PWA architecture with Material Design principles
- **Real-time UI Updates**: Live status updates for alerts, device states, and community coordination
- **Progressive Web App**: Offline-capable with service worker support and app manifest

### Backend Architecture
- **Node.js Express Server**: RESTful API with real-time WebSocket communication
- **Socket.IO Integration**: Bidirectional event-based communication for live alerts and device coordination
- **SQLite Database**: Lightweight embedded database for storing agents, alerts, and device data
- **JWT Authentication**: Token-based authentication system for agent dashboard access
- **Geolocation Processing**: Haversine distance calculations for proximity-based alert routing

### Data Storage Solutions
- **SQLite Database**: Single-file database containing:
  - Agents table: Authentication credentials, contact info, and locations
  - Alerts table: Emergency incidents with coordinates, timestamps, and status
  - Device simulation data for demonstration purposes
- **Session Management**: JWT tokens stored in localStorage for persistent agent sessions

### Authentication and Authorization
- **Agent Authentication**: Email/password login with bcrypt password hashing
- **Demo Credentials**: Seeded agent account (Delightchetter@gmail.com / 123456789)
- **JWT Token System**: Secure token-based session management
- **Role-based Access**: Agent dashboard protected by authentication middleware

### Real-time Communication System
- **WebSocket Architecture**: Socket.IO for instant bidirectional communication
- **Event-driven Updates**: Real-time alert broadcasting, device status updates, and community coordination
- **WebRTC Integration**: Voice calling capability between agents and emergency reporters
- **Proximity-based Routing**: Automatic device notification within configurable radius (60-100m)

### Emergency Alert Workflow
- **SOS Trigger**: One-button emergency alert with automatic geolocation capture
- **Radius Calculation**: Haversine formula to determine nearby devices within alert radius
- **Device Simulation**: 15-20 simulated community devices for demonstration
- **Multi-modal Notifications**: Visual alerts, audio ringtones, and push notifications
- **Agent Coordination**: Professional dashboard with satellite map integration and device management

### Map and Visualization
- **Satellite Imagery**: Leaflet.js with Esri WorldImagery tiles for agent dashboard
- **Interactive Overlays**: Alert radius circles, device markers, and real-time status indicators
- **Google Maps Integration**: External routing and navigation support
- **Responsive Mapping**: Mobile-optimized map controls and touch interactions

## External Dependencies

### Core Backend Dependencies
- **Express.js**: Web application framework and API routing
- **Socket.IO**: Real-time bidirectional event-based communication
- **SQLite3**: Embedded database engine for data persistence
- **bcrypt**: Password hashing and authentication security
- **jsonwebtoken**: JWT token generation and validation
- **cors**: Cross-origin resource sharing middleware
- **dotenv**: Environment variable management

### Frontend Libraries
- **Leaflet.js**: Interactive mapping library with satellite tile support
- **Socket.IO Client**: Browser WebSocket client for real-time communication
- **WebRTC API**: Browser-native peer-to-peer communication for voice calls

### Map Services
- **Esri WorldImagery**: Satellite tile provider for agent dashboard mapping
- **Google Maps**: External routing and navigation integration

### Audio and Media
- **Web Audio API**: Browser audio context for emergency ringtone playback
- **HTML5 Audio**: Cross-platform audio file support for panic alerts

### Development and Deployment
- **Node.js Runtime**: Server-side JavaScript execution environment
- **Flutter Framework**: Cross-platform mobile and web development (parallel implementation)
- **PWA Standards**: Service worker, web manifest, and offline capability support