# FireLink Emergency Alert System - HTML/PWA Project

A comprehensive emergency alert system that enables community-based rapid response coordination through real-time communication and location services.

## 🚀 Features

- **Emergency SOS System**: One-button emergency alert with geolocation
- **Real-time Community Alerts**: Live updates via Socket.IO
- **Agent Dashboard**: Professional emergency response interface
- **Satellite Map Integration**: Visual alert coordination with radius overlays
- **WebRTC Voice Calling**: Direct communication between agents and reporters
- **Device Simulation**: 20 simulated community devices for demonstration
- **Panic Ringtone System**: Audio alerts for nearby devices
- **Responsive Design**: Mobile-first PWA architecture

## 📋 Project Structure

```
firelink-emergency-system/
├── server.js                 # Main Node.js server with Express & Socket.IO
├── package.json              # Dependencies and scripts
├── .env.example              # Environment variables template
├── firelink.db              # SQLite database (auto-created)
├── public/                   # Static frontend files
│   ├── index.html           # SOS page (main emergency button)
│   ├── community.html       # Community alerts and device grid
│   ├── agent.html           # Agent dashboard with satellite map
│   ├── css/styles.css       # Complete CSS styling
│   ├── js/
│   │   ├── client.js        # SOS page functionality
│   │   ├── community.js     # Community page real-time features
│   │   └── agent.js         # Agent dashboard with WebRTC
│   ├── audio/
│   │   └── panic.mp3        # Panic ringtone (placeholder)
│   └── manifest.json        # PWA manifest
└── README-HTML.md           # This file
```

## 🛠️ Installation & Setup

### Prerequisites
- Node.js 18+ installed
- Modern web browser with WebRTC support
- Internet connection for satellite map tiles

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Environment Configuration (Optional)
```bash
cp .env.example .env
# Edit .env with your custom values if needed (default values work for demo)
```

### Step 3: Start the Server
```bash
npm run dev
```

The server will start on http://localhost:5000

### Step 4: Access the Application
- **SOS Page**: http://localhost:5000
- **Community Alerts**: http://localhost:5000/community  
- **Agent Dashboard**: http://localhost:5000/agent

## 🎯 How to Test the Demo

### Quick Demo Checklist:
1. ✅ **Start Backend**: Run `npm run dev` and verify server starts on port 5000
2. ✅ **Open 3 Browser Windows**: 
   - Window 1: http://localhost:5000 (SOS)
   - Window 2: http://localhost:5000/community (Community)
   - Window 3: http://localhost:5000/agent (Agent Dashboard)
3. ✅ **Trigger SOS**: Click the red SOS button in Window 1, confirm location permission
4. ✅ **Watch Simulation**: Observe 15-20 simulated phones receive alerts in Window 2
5. ✅ **Agent Login**: In Window 3, use credentials:
   - Email: `Delightchetter@gmail.com`
   - Password: `123456789`
6. ✅ **View Dashboard**: See incoming alert, satellite map, and device responses
7. ✅ **Test Communication**: Click "Voice Call Reporter" to initiate WebRTC demo

### Detailed Testing Steps:

#### 1. SOS Alert Flow
- Navigate to the main page (/)
- Adjust alert radius (60m, 80m, or 100m)
- Enable sound autoplay
- Click the large red SOS button
- Confirm the emergency alert in the modal
- Provide location permission or enter manual coordinates
- Verify success message with location confirmation

#### 2. Community Response
- Open /community in a separate browser window
- Watch for real-time alert notifications
- Observe the 20 simulated community devices in the grid
- See devices change status: idle → pinged → responded
- Check the satellite map with alert radius overlay
- Monitor the timeline for event logging

#### 3. Agent Dashboard
- Navigate to /agent and login with demo credentials
- View active alerts with full reporter information
- Examine the satellite map with all device locations
- Test voice calling functionality (WebRTC demo)
- Monitor device response statistics
- Use map controls to focus on alerts

## 🗺️ Demo Data

### Simulated Community Devices (20 total):
The system includes 20 simulated devices with GPS coordinates around Cape Town, South Africa:

```javascript
// Sample devices (full list in server.js)
{ id: 1, name: 'John\'s Phone', lat: -33.9249, lng: 18.4241, distance: 0 },
{ id: 2, name: 'Sarah\'s Phone', lat: -33.9250, lng: 18.4242, distance: 15 },
{ id: 3, name: 'Mike\'s Phone', lat: -33.9248, lng: 18.4240, distance: 12 },
// ... 17 more devices with varying distances (15m - 135m from center)
```

### Seeded Agent Account:
- **Email**: Delightchetter@gmail.com
- **Password**: 123456789
- **Role**: Emergency Response Agent
- **Location**: Cape Town, South Africa (-33.9249, 18.4241)

## 🔧 Technical Implementation

### Backend (Node.js + Express):
- **REST API**: `/api/alerts`, `/api/agents/login`, `/api/demo/devices`
- **Socket.IO**: Real-time events for community and agents
- **SQLite Database**: Alerts and agent storage
- **WebRTC Signaling**: Voice call coordination
- **Haversine Distance**: Accurate geo-radius calculations

### Frontend Features:
- **Responsive Design**: Mobile-first CSS with Flexbox/Grid
- **Real-time Updates**: Socket.IO client integration
- **Leaflet Maps**: Satellite imagery with custom markers
- **WebRTC**: Peer-to-peer voice calling
- **PWA Support**: Service worker ready, installable
- **Audio Integration**: Panic ringtone with autoplay handling

### Security & Authentication:
- **JWT Tokens**: Secure agent authentication
- **Password Hashing**: bcrypt for secure storage
- **CORS Configuration**: Proper cross-origin handling
- **Input Validation**: Sanitized location data

## 🌐 Production Deployment Notes

### Environment Variables:
```bash
# Required for production
JWT_SECRET=your-super-secret-jwt-key
DATABASE_URL=./firelink.db

# Optional integrations
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
MAPBOX_API_KEY=your_mapbox_key
```

### Production Integrations:
1. **SMS/USSD Fallback**: Integrate Twilio for offline device alerts
2. **Real Hardware**: Connect to Lumkani-style IoT heat sensors
3. **Municipal EMS**: API integration with local emergency services
4. **Professional Maps**: Upgrade to Mapbox or Google Maps with API keys
5. **Push Notifications**: VAPID keys for background notifications

## 🚨 Demo vs Production

This is a **demonstration prototype** with the following limitations:

### Demo Features:
- ✅ Simulated 20 community devices
- ✅ Mock emergency response
- ✅ WebRTC voice calling demo
- ✅ Satellite map visualization
- ✅ Real-time Socket.IO communication

### Production Requirements:
- 🔧 Real IoT hardware integration
- 🔧 Municipal emergency service APIs
- 🔧 SMS gateway for offline devices
- 🔧 Professional monitoring dashboard
- 🔧 Redundant server infrastructure
- 🔧 Emergency services dispatch integration

## 🆘 Troubleshooting

### Common Issues:

**1. Server won't start:**
```bash
# Check if port 5000 is available
lsof -i :5000
# Kill any processes using the port
kill -9 <PID>
```

**2. Location permission denied:**
- Enable location services in your browser
- Use manual coordinates: Cape Town (-33.9249, 18.4241)

**3. WebRTC not working:**
- Ensure HTTPS in production (required for WebRTC)
- Check browser console for ICE candidate errors
- Verify STUN server accessibility

**4. Audio not playing:**
- Click "Enable sound autoplay" checkbox
- Interact with the page first (browser autoplay policy)
- Check browser audio permissions

**5. Map tiles not loading:**
- Verify internet connection
- Check Esri WorldImagery tile service status
- Consider switching to OpenStreetMap tiles

### Browser Compatibility:
- ✅ Chrome 80+
- ✅ Firefox 75+
- ✅ Safari 13+
- ✅ Edge 80+
- ⚠️ IE not supported (WebRTC requirement)

## 🔮 Next Steps

1. **Hardware Integration**: Connect real fire detection sensors
2. **EMS Integration**: Municipal emergency services API
3. **Mobile Apps**: Native iOS/Android applications  
4. **SMS Fallback**: Twilio integration for offline alerts
5. **Analytics Dashboard**: Response time metrics and reporting
6. **Multi-language**: Localization for different regions

## 📞 Support

For technical issues or questions about this demonstration:
- Check the browser console for error messages
- Verify all services are running on the correct ports
- Test with multiple browser windows for full demo experience

---

**Important**: This is a prototype demonstration. Real-world deployment requires integration with professional emergency services, proper security auditing, and compliance with local emergency response regulations.