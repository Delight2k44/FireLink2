# FireLink Emergency Alert System - Flutter Project

A cross-platform mobile and web emergency alert system built with Flutter, featuring real-time community coordination and WebSocket communication.

## 🚀 Features

- **Cross-platform**: Runs on Android, iOS, and Web (PWA)
- **Real-time Communication**: WebSocket integration with Node.js backend
- **Emergency SOS**: One-tap emergency alerts with location services
- **Community Integration**: Live device status and alert coordination
- **Agent Dashboard**: Professional emergency response interface
- **Voice Calling**: WebRTC integration for agent-reporter communication
- **Offline Fallback**: Graceful degradation when network unavailable
- **Material Design**: Native Flutter UI with consistent branding

## 📋 Project Structure

```
flutter_firelink/
├── lib/
│   ├── main.dart                    # App entry point and routing
│   ├── pages/
│   │   ├── home_page.dart          # SOS emergency button page
│   │   ├── community_page.dart     # Community alerts (to be created)
│   │   └── agent_dashboard.dart    # Agent response interface (to be created)
│   ├── services/
│   │   ├── socket_service.dart     # WebSocket/Socket.IO communication
│   │   ├── location_service.dart   # GPS and location handling
│   │   └── audio_service.dart      # Ringtone and audio management
│   ├── widgets/
│   │   └── navigation_bar.dart     # Custom navigation component
│   └── models/                     # Data models (to be created)
├── assets/
│   ├── audio/                      # Audio files (panic ringtone)
│   └── images/                     # App icons and graphics
├── android/                        # Android-specific configuration
├── web/                           # Web deployment files
├── pubspec.yaml                   # Flutter dependencies
└── README-Flutter.md              # This file
```

## 🛠️ Installation & Setup

### Prerequisites
- Flutter SDK 3.0.0 or higher
- Dart SDK (included with Flutter)
- Android Studio / VS Code with Flutter extensions
- Node.js backend server (from HTML project)

### Step 1: Install Flutter
```bash
# Download Flutter SDK from https://flutter.dev/docs/get-started/install
# Add Flutter to your PATH

# Verify installation
flutter doctor
```

### Step 2: Get Dependencies
```bash
cd flutter_firelink
flutter pub get
```

### Step 3: Start the Backend Server
```bash
# In the root project directory (not flutter_firelink)
npm run dev
```

### Step 4: Configure Backend URL
Edit `lib/services/socket_service.dart`:
```dart
static const String serverUrl = kDebugMode 
  ? 'http://localhost:5000'        # For local development
  : 'https://your-replit-url.com'; # Your Replit URL for production
```

### Step 5: Run Flutter Application

#### Web (Recommended for Demo):
```bash
flutter run -d chrome --web-port 3000
```

#### Android Emulator:
```bash
# Start Android emulator first
flutter run
```

#### Physical Device:
```bash
# Enable USB debugging on your Android device
flutter run
```

## 🎯 How to Test the Flutter Demo

### Quick Demo Checklist:
1. ✅ **Start Backend**: Run `npm run dev` (Node.js server on port 5000)
2. ✅ **Launch Flutter Web**: `flutter run -d chrome --web-port 3000`
3. ✅ **Test SOS Flow**: 
   - Click red SOS button
   - Grant location permission
   - Confirm emergency alert
   - Verify success message
4. ✅ **Multi-window Testing**: 
   - Open http://localhost:5000/community (HTML version)
   - Trigger SOS from Flutter app
   - Watch real-time alerts appear in HTML community page
5. ✅ **Agent Dashboard**: Login at http://localhost:5000/agent with demo credentials

### Detailed Testing Steps:

#### 1. Emergency Alert (Flutter App)
- Open Flutter app (SOS page is default)
- Adjust settings: sound autoplay and alert radius
- Tap the large red SOS button
- Handle location permission dialog
- Confirm emergency alert in dialog
- Verify success message with location details

#### 2. Cross-platform Testing
- **Web**: Access via browser at localhost:3000
- **Android**: Install APK and test with mobile location services
- **Real-time**: Keep HTML community page open to see Flutter alerts

#### 3. Integration Testing
- Flutter app sends SOS → HTML community page shows alert
- HTML community devices respond → Flutter app receives updates
- Agent dashboard tracks all Flutter-originated alerts

## 📱 Platform-Specific Features

### Web (PWA):
- ✅ Installable web app
- ✅ Responsive design
- ✅ WebRTC voice calling
- ✅ Location API integration
- ✅ Audio playback support

### Android:
- ✅ Native location services
- ✅ Push notifications (ready)
- ✅ Background processing capability
- ✅ Audio playback with volume controls
- ✅ WebRTC native support

### iOS (Future):
- 📋 Native location services
- 📋 APNs push notifications
- 📋 Background app refresh
- 📋 WebRTC CallKit integration

## 🔧 Dependencies Explained

### Core Flutter:
- `flutter`: Framework and UI toolkit
- `cupertino_icons`: iOS-style icons

### Real-time Communication:
- `socket_io_client`: WebSocket client for real-time events
- `http`: REST API communication

### Location & Maps:
- `flutter_map`: Interactive maps with satellite tiles
- `latlong2`: Geographic coordinate calculations
- `geolocator`: GPS location services
- `permission_handler`: Runtime permissions

### Media & Audio:
- `audioplayers`: Panic ringtone playback
- `flutter_webrtc`: Voice calling capabilities

### State & Storage:
- `provider`: State management
- `shared_preferences`: Local settings storage

### Utilities:
- `json_annotation`: Model serialization
- `json_serializable`: Code generation for JSON

## 🎨 Flutter-Specific UI Features

### Material Design Integration:
```dart
// Custom theme matching brand colors
ThemeData(
  primarySwatch: Colors.red,
  primaryColor: Color(0xFFDC2626), // FireLink red
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: Color(0xFFDC2626),
      foregroundColor: Colors.white,
    ),
  ),
)
```

### Responsive Design:
- Mobile-first layout with adaptive components
- Consistent navigation across all platforms
- Touch-optimized buttons and interactions
- Platform-specific UI patterns (Material vs Cupertino)

### Animation & Feedback:
- Pulsing SOS button with gradient effects
- Loading states during location acquisition
- Success/error feedback with appropriate colors
- Smooth page transitions

## 🌐 Real-time Features

### WebSocket Integration:
```dart
// Socket.IO client connecting to Node.js backend
IO.Socket socket = IO.io('http://localhost:5000', {
  'transports': ['websocket'],
  'autoConnect': false,
});

// Listen for real-time events
socket.on('new_alert', (data) => handleNewAlert(data));
socket.on('play_ringtone', (data) => handleRingtoneEvent(data));
```

### Cross-platform Communication:
- Flutter SOS triggers → HTML community alerts
- HTML device responses → Flutter real-time updates  
- Agent dashboard controls → Flutter notifications

## 🔒 Security & Permissions

### Android Permissions (android/app/src/main/AndroidManifest.xml):
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
```

### Web Permissions:
- Geolocation API for location services
- MediaDevices API for WebRTC calling
- Web Audio API for ringtone playback
- Service Worker for PWA functionality

### iOS Permissions (ios/Runner/Info.plist):
```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>FireLink needs location access to send accurate emergency alerts</string>
<key>NSMicrophoneUsageDescription</key>
<string>FireLink needs microphone access for voice calls with emergency responders</string>
```

## 🚨 Production Deployment

### Web Deployment:
```bash
# Build for web
flutter build web --release

# Deploy to static hosting
# Copy build/web/* to your web server
```

### Android Release:
```bash
# Build APK
flutter build apk --release

# Build App Bundle (recommended)
flutter build appbundle --release
```

### Environment Configuration:
```dart
// Update socket_service.dart for production
static const String serverUrl = kDebugMode 
  ? 'http://localhost:5000'           // Development
  : 'https://your-domain.com';        // Production
```

## 🔧 WebRTC Voice Calling

### Flutter WebRTC Setup:
```dart
// Initialize peer connection
RTCPeerConnection pc = await createPeerConnection({
  'iceServers': [
    {'urls': 'stun:stun.l.google.com:19302'}
  ]
});

// Handle incoming calls from agents
socket.on('webrtc_offer', (offer) async {
  await pc.setRemoteDescription(
    RTCSessionDescription(offer['sdp'], offer['type'])
  );
  
  RTCSessionDescription answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  socket.emit('webrtc_answer', answer.toMap());
});
```

### Fallback Options:
If WebRTC proves complex in Flutter web:
1. **Simulated Call UI**: Display call interface with recorded audio
2. **External App Integration**: Deep link to phone app
3. **Twilio Voice SDK**: Professional voice calling service

## 🧪 Testing Scenarios

### Unit Testing:
```bash
flutter test
```

### Integration Testing:
1. **Location Services**: Test with/without GPS permission
2. **Network Connectivity**: Test offline/online scenarios  
3. **Real-time Events**: Verify WebSocket message handling
4. **Audio Playback**: Test ringtone on different devices
5. **Cross-platform**: Ensure consistency across web/mobile

### Demo Testing:
1. Start Node.js backend server
2. Launch Flutter web application
3. Open HTML community page in separate browser
4. Trigger SOS from Flutter → verify HTML receives alert
5. Test device responses from HTML → verify Flutter updates

## 🐛 Troubleshooting

### Common Issues:

**1. WebSocket connection failed:**
```dart
// Check backend URL configuration
static const String serverUrl = 'http://localhost:5000';

// Verify backend server is running
// Check browser console for CORS errors
```

**2. Location permission denied:**
```dart
// Handle permission gracefully
try {
  Position position = await Geolocator.getCurrentPosition();
} catch (e) {
  // Fallback to manual coordinates or default location
  Position defaultPosition = Position(
    latitude: -33.9249, longitude: 18.4241, // Cape Town
    timestamp: DateTime.now(),
    // ... other required fields
  );
}
```

**3. Audio not playing:**
```dart
// Check platform-specific audio permissions
// Ensure user interaction before autoplay (web)
// Test with different audio file formats
```

**4. Flutter web build issues:**
```bash
# Clear build cache
flutter clean
flutter pub get

# Rebuild web files
flutter build web --release
```

**5. Hot reload not working:**
```bash
# Restart with hot reload enabled
flutter run --hot
```

### Platform-Specific Debugging:

**Web Debug:**
```bash
flutter run -d chrome --web-renderer html
```

**Android Debug:**
```bash
flutter run --debug
flutter logs
```

## 🔮 Flutter Roadmap

### Phase 1 - Current Demo:
- ✅ Basic SOS functionality
- ✅ Real-time WebSocket communication
- ✅ Location services integration
- ✅ Cross-platform web/Android support

### Phase 2 - Enhanced Features:
- 📋 Complete community page with device grid
- 📋 Agent dashboard with map integration
- 📋 WebRTC voice calling implementation
- 📋 Push notifications for background alerts

### Phase 3 - Production Ready:
- 📋 iOS native application
- 📋 Background processing and notifications
- 📋 Offline mode with local storage
- 📋 Professional UI/UX refinements

### Phase 4 - Advanced Integration:
- 📋 Bluetooth IoT sensor integration
- 📋 Machine learning for false alarm detection
- 📋 Multi-language localization
- 📋 Analytics and reporting dashboard

## 📞 Flutter Support

### Development Environment:
```bash
# Check Flutter installation
flutter doctor -v

# Update Flutter to latest stable
flutter upgrade

# List available devices
flutter devices
```

### IDE Setup:
- **VS Code**: Install Flutter + Dart extensions
- **Android Studio**: Install Flutter plugin
- **IntelliJ IDEA**: Install Dart + Flutter plugins

### Debugging Tools:
- Flutter Inspector for widget tree analysis
- Dart DevTools for performance profiling
- Network profiler for API call monitoring
- Console logs for real-time debugging

---

**Important**: This Flutter project requires the Node.js backend server to be running for full functionality. The Flutter app acts as a client to the centralized emergency coordination system.